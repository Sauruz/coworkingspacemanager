<?php

$colors = array(
    "#4FC3F7" => "Blue",
    "#FF9800" => "Orange",
    "#7E57C2" => "Purple",
    "#4CAF50" => "Green",
    "#EA80FC" => "Pink",
    "#E53935" => "Red",
    "#78909C" => "Turquoise"
);

?>
