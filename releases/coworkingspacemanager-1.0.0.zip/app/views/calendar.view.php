<div class="wrap">
    <h1 class="wp-heading-inline"><strong>Calendar</strong></h1>
    <div class="bootstrap-wrapper">
         <?php include CSM_PLUGIN_PATH . 'app/views/tabbar/calendar.tabbar.php'; ?>

         <div id='calendar'></div>   
    </div>
</div>