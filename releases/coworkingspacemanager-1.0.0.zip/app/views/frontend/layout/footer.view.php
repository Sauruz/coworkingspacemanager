            </div>
        </div>
        <script src="<?php echo plugins_url() . '/coworkingspacemanager/dist/js/app.js';?>"></script>
        <script src="<?php echo plugins_url() . '/coworkingspacemanager/dist/js/i18n/angular-locale_' . CMS_LOCALE . '.js';?>"></script>
    </body>
</html>