<ul class="nav nav-tabs">
    <li class="<?php tab_active('csm-members'); ?>"><a href="?page=csm-members"><i class="fa fa-fw fa-users" aria-hidden="true"></i> All Members</a></li>
    <li class="<?php tab_active('csm-member-add'); ?>"><a href="?page=csm-member-add"><i class="fa fa-plus" aria-hidden="true"></i> Add Member</a></li>
</ul>