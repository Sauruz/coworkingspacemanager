<ul class="nav nav-tabs">
    <li class="<?php tab_active('csm-memberships'); ?>"><a href="?page=csm-memberships"><i class="fa fa-fw fa-list" aria-hidden="true"></i> All Memberships</a></li>
    <li class="<?php tab_active('csm-membership-add'); ?>"><a href="?page=csm-membership-add"><i class="fa fa-plus" aria-hidden="true"></i> Add Membership</a></li>
</ul>