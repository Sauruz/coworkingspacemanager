<ul class="nav nav-tabs">
    <li class="<?php tab_active('csm-settings'); ?>"><a href="?page=csm-settings"><i class="fa fa-fw fa-cogs" aria-hidden="true"></i> Settings</a></li>
</ul>   