<ul class="nav nav-tabs">
    <li class="<?php tab_active('csm-calendar');?>"><a href="?page=csm-calendar"><i class="fa fa-fw fa-calendar" aria-hidden="true"></i> Calendar</a></li>
</ul>